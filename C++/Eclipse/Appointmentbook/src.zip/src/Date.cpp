/*
 * Date.cpp
 *
 *  Created on: 2009-09-10
 *  Modified on 2018-09-08
 *      Author: piotr
 *
 */


#include "Date.h"
#include <ctime>
#include <stdexcept>

// Default constructor; sets date to "today" (current date)
Date::Date()
{
	SetCurrentDate();
}

// Another constructor; sets date as requested.
// If no year is provided, the current year is assumed.
Date::Date(int d, int m, int y /* =0 */)
: yr_{y?y:CurrentDate().year_}, mo_{m}, dy_{d}
{
	// If a requested date is bad, it is set to the current date
	if ( ! isOK( dy_, mo_, yr_ ) )
		SetCurrentDate();

}

// A constructor that allows initialize date object from a string
// (accepts two formats only)
Date::Date(std::string s)
{
 std::string sep="/";
 unsigned long int pos{0};


   //Note:  mm/dd/yyyy OR dd-mm-yyyy

   if ( ( pos=s.find(sep)) == std::string::npos ) {
      // Not this format; let's try the other one
      sep = "-";
      if ( (pos=s.find(sep)) == std::string::npos ) {
         // Neither format; initialize to current
         SetCurrentDate();
         return;
      }
   }

   while ( pos != std::string::npos ) {
         s.replace( pos, 1,  " ");
         pos=s.find(sep, pos);
      }

   // Let's read day, month and year... from the string:
   std::istringstream in(s);

   if (in >> dy_ >> mo_ >> yr_ ) {

      if ( sep == "/" ) {  // Swap day and month
            pos = dy_;
            dy_ = mo_;
            mo_ = pos;
      }

      if ( isOK( dy_, mo_, yr_ ) )
         return;
   }

	if ( ! isOK( dy_, mo_, yr_ ) ) {
	    SetCurrentDate();
    }    // Was Bad again :(


   // other formats ?...

}

// Destructor - not really needed.
Date::~Date()
{
	// Could print something, to test when it is called, I guess...
}


// The advance function resets the date by n days.
void Date:: advance (int n)
{
	int d{0};
	dy_ += n;
	while ( dy_ > (d=daysPM(mo_, yr_))) {
		dy_ -= d;
		if (++mo_ > 12 ) {
			mo_ = 1;
			yr_++;
		}
	}
	while ( dy_ < 1 ) {
		if ( --mo_ < 1 ) {
			mo_ =12;
			yr_--;
		}
		dy_ += daysPM (mo_, yr_);
	}

}

// The adddays function computes and returns a new date (value)
// n days from the one given; the original date is not modified.
// The sput function returns date as a string.
// Note that string class does not provide any means
// to convert integers into "strings".
// I create an object of type "ostringstream" that allows
// output to a string... (more on this later)

Date Date::adddays(int x) const
{
  Date tmp(*this);
	tmp.advance(x);
	return tmp;
}



std::string Date::sput()
{
    std::ostringstream sout{};
    sout << mo_ << "/" << dy_ << "/" << yr_ ;

    return (sout.str());
}


// These are private functions..

// Is this date OK?
bool Date::isOK ( int d, int m, int y)
{
    return ( y > 0 && m > 0 && m < 13 && d > 0 && d <= daysPM(m, y));
}

void Date::SetCurrentDate()
{
		CurrentDate X{};
		yr_=X.year_;
		mo_=X.month_;
		dy_=X.day_;
}

// Days per month...
int Date::daysPM(int m, int y){
	static int const dpm[]={0,31,28,31,30,31,30,31,31,30,31,30,31};
	if (m != 2)
		return (dpm[m]);
	else
		return (28 + (y % 4 == 0) - (y % 100 ==0) + (y % 400 == 0));
}

// The current (system) date
Date::CurrentDate::CurrentDate()
{
 time_t now{};
 tm * current{};

	// Getting current system time...
    if ( time(&now) == (time_t) -1 ) {
        std::cerr << "Current time not available :( \n";
        exit (2);
    }

	current=localtime(&now);

	day_=current->tm_mday;
	month_=current->tm_mon+1;
	year_=current->tm_year+1900;

	// ... done.
}

// And some friends...


// Days between two dates:
int operator- (const Date& a, const Date& b)
{
  const int yr0{1970};  // This really doesn't matter; could be 1900, or 2000

  Date d[]={a, b};
  int ju[]={0,0};

  for (int i=0; i<2; i++)
	  if ( d[i].yr_ >= yr0 ) {
		for ( int y = yr0; y < d[i].yr_ ; y++ )
			ju[i] += 365 + (y % 4 == 0) - (y % 100 ==0) + (y % 400 == 0);
		for ( int m = 1 ; m < d[i].mo_ ; m++ )
			ju[i] += Date::daysPM(m, d[i].yr_);

		ju[i] += d[i].dy_;
	  }
	  else {
		for ( int y = yr0 - 1; y > d[i].yr_ ; y-- )
			ju[i] -= 365 - ((y % 4 == 0) - (y % 100 ==0) + (y % 400 == 0));
		for ( int m = 12 ; m > d[i].mo_ ; m-- )
			ju[i] -= Date::daysPM(m, d[i].yr_);

		ju[i] -= Date::daysPM(d[i].mo_, d[i].yr_) - d[i].dy_ ;
	  }


  return ju[0] - ju[1];


}

// Sending Date to an output stream:
std::ostream& operator<<( std::ostream& s, const Date& x )
{
	s << x.yr_ << "-" << x.mo_ << "-" << x.dy_ ;

	return s;
}

// Extracting Date from an input stream;
// the approach taken is unforgiving, just to demonstrate use of exceptions...
std::istream& operator>>( std::istream& s, Date& x )
{
 char c{};
 int y{}, m{}, d{};
	s >> y;
	c=s.get();
		if (c != '-')   // Bad Date!
			throw std::runtime_error("Bad date input format.");      // ...
	s >> m;
	c=s.get();
		if (c != '-')   // Bad Date!
			throw std::runtime_error("Bad date input format.");      // ...
	s >> d;

	if ( x.isOK( d, m, y) ) {
		x.yr_=y;
		x.mo_=m;
		x.dy_=d;
	}
	else
		throw std::runtime_error("Bad date!");

	return s;
}

// Date comparison: are they equal?
bool operator==( const Date& a, const Date& b ) {

	return a.dy_ == b.dy_ && a.mo_ == b.mo_ && a.yr_ == b.yr_;
}

// Date comparison: strict precedence
bool operator<( const Date& a, const Date& b ) {

	if ( a.yr_ != b.yr_)
		return a.yr_ < b.yr_;
		else if ( a.mo_ != b.mo_ )
			return a.mo_ < b.mo_;
			else
				return a.dy_ < b.dy_;
}
