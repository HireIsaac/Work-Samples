/*
 * Main.cpp
 *
 *  Created on: Nov 20, 2018
 *      Author: Isaac Lohnes
 */

#include "Appointment.h"
#include "OneTime.h"
#include "Daily.h"
#include "Weekly.h"
#include "NewAppointment.h"
#include "AppointmentBook.h"
#include "CheckAppointments.h"
//created includes

#include "Factory.h"
#include "Systime.h"
#include "Menu.h"
//Piotrs headers

#include <iostream>
using namespace std;





Appointment * newOneTime(){
	return new OneTime();
}

Appointment * newDaily(){
	return new Daily();
}

Appointment * newWeekly(){
	return new Weekly();
}
//above is for factory register









int main() {
	Factory<Appointment, char> * factory {Factory<Appointment, char>::Instance()};
	AppointmentBook * appointmentbook = new AppointmentBook();
	//init

	factory->Register('W', newWeekly);
	factory->Register('T', newOneTime);
	factory->Register('D', newDaily);
	//bind to functions





	Menu Mn("Menu");
	Mn.addItem("Create new appointment", new NewAppointment(factory, appointmentbook));
	Mn.addItem("List appointments",new CheckAppointments(appointmentbook));
	Mn();
	//make menu, add items

	return 0;
}




