/*
 * Appointment.h
 */

#ifndef APPOINTMENT_H_
#define APPOINTMENT_H_

#include "Date.h"

#include <cstring>
#include <iostream>

using namespace std;

class Appointment{
public:
	Appointment();
	virtual ~Appointment();
	virtual bool isDue(Date & dateToCompare) = 0;
	Date getDateOb(){
		return date;
	};
	string getTime();
	string getDate();
	void setDate(Date newDate){
		date = newDate;
	};
	void setName(string newName){
		name = newName;
	};
	string getName();
	void setDescription(string newDescription){
		description = newDescription;
	};
	int checkOccurrence(){
		return occurrence;
	};
	void setReoccurrence(int newRec){
		waitTime= newRec;
	};

	string getType(){
		return type;
	};

protected:
	Date date;
	string type;
	int occurrence;
	int waitTime;
	string name;
	string description;

};

#endif

