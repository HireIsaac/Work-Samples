

#include "NewAppointment.h"

NewAppointment::NewAppointment(Factory<Appointment, char> * fact, AppointmentBook * ab){
	factory = fact;
	appointmentbook = ab;
}

NewAppointment::~NewAppointment(){

}

void NewAppointment::operator()() {

	char selectedType = 'T';
	string selectedDate = "";
	string selectedName = "";
	string selectedDescription = "";
	int selectedReoccurrence = -1;
	bool sVal = true;	//always true, hahahah not the best code
	//init for cin



	cout << "Select appointment type: " << endl;
	cin.ignore(10, '\n');
	cin >> selectedType;
	//Build check that appointment is correct here.
	//Something something cin.ignore, I'll build it
	//eventually.

	while(cin.get()!='\n');


	cout << "Select date (DD-MM-YYYY): " << endl;
	while(sVal){
		getline(cin, selectedDate);
		if(selectedDate != ""){
			break;
		}

	}


	cout << "Appointment name: "  << endl;
	while(sVal){
			getline(cin, selectedName);
			if(selectedName != ""){
				break;
			}

		}

	cout << "Appointment Description: " << endl;
	while(sVal){
			getline(cin, selectedDescription);
			if(selectedDescription != ""){
				break;
			}

		}

	cout << "Appointment Reoccurrence: " << endl;
		while(sVal){
				cin >> selectedReoccurrence;
				if(selectedReoccurrence != -1){
					break;
				}

			}


		//above I/O doesn't really have handling
		//for poor user input. I'd like to build
		//that out more in the future. NOTE TO SELF

	Appointment * app = factory->Create(selectedType);
	//Create appointment based on what is bound in factory



	app->setDate(Date(selectedDate));
	app->setName(selectedName);
	app->setDescription(selectedDescription);
	app->setReoccurrence(selectedReoccurrence);
	//Set everything from io


	appointmentbook->addAppointment(app);
	//Add appointment to list


}
