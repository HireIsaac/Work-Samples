#include "CheckAppointments.h"

CheckAppointments::CheckAppointments(AppointmentBook * ab){
	appointmentbook = ab;
}

CheckAppointments::~CheckAppointments(){}

void CheckAppointments::operator()(){

	cout << "Date to check appointments (DD-MM-YYYY format):" << endl;
	string uInput;
	while(true){
		//I do this while(true) a few other times
		//in my code, to prevent all my printing to
		//happen all at once.
		//I'd like to find a better way to do this, but I'm short on time atm.
		getline(cin,uInput);
		if(uInput!=""){
			break;
		}
	}


	vector<Appointment *> currentAppointments;

	vector<Appointment *>::iterator iterator;

	if(appointmentbook->isEmpty()){
		cout << empty <<endl;
	}else{
		//Printing here, room for improvement in formatting
		currentAppointments = appointmentbook->checkForAppointments(Date(uInput));
		cout << uInput << endl;
		for(iterator = currentAppointments.begin(); iterator < currentAppointments.end(); iterator++){
			Appointment * app = *iterator;
			cout << app->getName() << "," << app->getDateOb().sput() << "," << app->getType() << endl;
		}

	}

}
