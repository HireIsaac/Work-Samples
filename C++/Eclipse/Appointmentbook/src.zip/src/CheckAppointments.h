/*
 * CheckAppointments.h
 *
 *  Created on: Nov 28, 2018
 *      Author: Isaac Lohnes
 */

#ifndef CHECKAPPOINTMENTS_H_
#define CHECKAPPOINTMENTS_H_

#include "AppointmentBook.h"
#include "Runnable.h"
#include <iostream>
using namespace std;

class CheckAppointments: public Runnable{
public:
	CheckAppointments(AppointmentBook * ab);
	virtual ~CheckAppointments();
	void operator()();
private:
	AppointmentBook * appointmentbook;
	string col= "Appointments for: | Date : | Type:";
	//Currently, this is where I plan on building more formatting
	string empty="No appointments found";
};



#endif /* CHECKAPPOINTMENTS_H_ */
