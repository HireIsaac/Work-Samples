/*
 * Weekly.cpp
 *
 *  Created on: Nov 29, 2018
 *      Author: Isaac Lohnes
 */

#include "Weekly.h"

Weekly::Weekly() {
	occurrence=7;
	type = "Weekly";
}

Weekly::~Weekly() {
}

bool Weekly::isDue(Date & dateToCompare){
	int i = 0;
	do{
		if(dateToCompare < date){
			return false;
		}if(dateToCompare == date){
			return true;
		}
		date.advance(occurrence);

	}while(waitTime == 0 || ++i<waitTime);
	return false;
}


