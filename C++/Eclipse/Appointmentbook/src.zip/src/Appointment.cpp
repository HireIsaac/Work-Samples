/*
 * Appointment.cpp
 */

#include "Appointment.h"

Appointment::Appointment():type(""),occurrence(0),waitTime(0),date(""),name(""),description(""){

}

Appointment::~Appointment(){

}

string Appointment::getName(){
	return name;
}
