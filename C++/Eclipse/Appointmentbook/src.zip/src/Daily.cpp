/*
 * Daily.cpp
 *
 *  Created on: Nov 20, 2018
 *      Author: Isaac Lohnes
 */


#include "Daily.h"

Daily::Daily() {
	type = "Daily";
	occurrence = 1;
}

Daily::~Daily() {
}

bool Daily::isDue(Date & dateToCompare){
	//uses your date, compares and iterates through waitTime
	int i = 0;
	do{
		if(dateToCompare < date){
			return false;
		}if(dateToCompare == date){
			return true;
		}
		date.advance(occurrence);

	}while(waitTime == 0 || ++i<waitTime);
	return false;
}
