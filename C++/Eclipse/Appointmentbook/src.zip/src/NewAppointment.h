/*
 * NewAppointment.h
 *
 *  Created on: Nov 29, 2018
 *      Author: Isaac Lohnes
 */

#ifndef NEWAPPOINTMENT_H_
#define NEWAPPOINTMENT_H_

#include "Runnable.h"
#include "AppointmentBook.h"
#include "Factory.h"
#include <iostream>

using namespace std;

class NewAppointment:public Runnable {

public:
	NewAppointment(Factory<Appointment,char> * fact, AppointmentBook * ab);
	virtual ~NewAppointment();
	void operator()();	//op overload

private:
	Factory<Appointment, char> * factory;
	AppointmentBook * appointmentbook;
};




#endif /* NEWAPPOINTMENT_H_ */
