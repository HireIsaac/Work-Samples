/*
 * AppointmentBook.h
 *
 *  Created on: Nov 22, 2018
 *      Author: Isaac Lohnes
 */

#ifndef APPOINTMENTBOOK_H_
#define APPOINTMENTBOOK_H_

#include <vector>
#include <iostream>

#include "Appointment.h"
using namespace std;

class AppointmentBook {
public:
	AppointmentBook();
	virtual ~AppointmentBook();
	bool isEmpty();
	void addAppointment(Appointment *);
	void removeAppointment(); //unused currently
	vector<Appointment *> checkForAppointments(Date compareDate);
	//show appointments in list

private:
	vector<Appointment *> appointments;
	//array of appointments
};




#endif /* APPOINTMENTBOOK_H_ */
