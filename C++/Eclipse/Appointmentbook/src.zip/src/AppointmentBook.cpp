/*
 * AppointmentBook.cpp
 *
 *  Created on: Nov 22, 2018
 *      Author: Isaac Lohnes
 */


#include "AppointmentBook.h"

AppointmentBook::AppointmentBook() {
}

AppointmentBook::~AppointmentBook() {
}

void AppointmentBook::addAppointment(Appointment * app) {
	//add appointments to array
	vector<Appointment *>::iterator iterator = appointments.end();
	if(isEmpty()){
		iterator= appointments.begin();
	}
	appointments.insert(iterator,app);
}

void AppointmentBook::removeAppointment() {
	//something here to remove appointments from vector appointments
}

bool AppointmentBook::isEmpty(){
	//return bool based on appointments size
	if(appointments.size() ==0){
		return true;
	}else{
		return false;
	}
}


vector<Appointment *> AppointmentBook::checkForAppointments(Date compareDate){
	//checks for appointments on specifc date
	vector<Appointment *> compareAppointments;
	vector<Appointment *>::iterator iterator;
	for(iterator = appointments.begin(); iterator < appointments.end(); iterator++){
		Appointment * app = *iterator;
		if(app->isDue(compareDate)){
			compareAppointments.push_back(app);
		}
	}
	return compareAppointments;
}



