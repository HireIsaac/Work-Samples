/*
 * Daily.h
 *
 *  Created on: Nov 20, 2018
 *      Author: Isaac Lohnes
 */

#ifndef DAILY_H_
#define DAILY_H_


#include "Appointment.h"
class Daily: public Appointment {
public:
	Daily();
	virtual ~Daily();
	bool isDue(Date & dateToCompare);
};




#endif /* DAILY_H_ */
