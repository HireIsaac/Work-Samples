/*
 * OneTime.cpp
 *
 *  Created on: Nov 29, 2018
 *      Author: Isaac Lohnes
 */

#include "OneTime.h"

OneTime::OneTime() {
	type = "One time";
	occurrence = 0;
}

OneTime::~OneTime() {
}

bool OneTime::isDue(Date & dateToCompare){
	//differs from weekly and daily, only needs to check
	//dateToCompare
	if(dateToCompare < date){
		return false;
	}if(dateToCompare == date){
		return true;
	}
	return false;
}


