/*
 * Date.h
 *
 *  Created on: 2009-09-10
 *      Author: piotr
 *
 *  Modified on 2018-09-08  by piotr
 */

#include <iostream>
#include <sstream>
#include <string>
#include <iomanip>

#ifndef MY_DATE_H
#define MY_DATE_H


class Date final
{
public:
	Date();		           		// Default constructor...
	Date(int, int, int = 0);   	// A constructor
	Date(std::string);	        // Another constructor
	Date(const Date&)=default;
	Date(Date&&)=default;
	virtual ~Date();      	   	// A destructor

	// These "access" functions produce day, month or year:
	int day() const 	  		// All are defined "in-line"...
		{ return dy_; }
	int month() const     		// "const" here mean that these functions do not
		{ return mo_; }
	int year() const      		//  modify object's data
		{ return yr_; }

	void advance(int);    		// ...advances this date by a number of days...

	Date adddays(int) const;  	// ...returns a new Date that differs by
				  	  	  	  	// a number of days from this one.


	void put();		// This is also defined in-line, but outside of the the class definition,
					// - at the bottom of this header.

	/* The following we will discuss later... */
	Date& operator= (const Date&) = default;
	Date& operator= (Date&&) = default;

	std::string sput();
	const Date& operator++() { this->advance(1); return *this; }
	Date operator++(int)
	{ Date tmp(*this);  this->advance(1); return tmp; }

	friend int operator-( const Date&, const Date& );
	friend std::ostream& operator<<( std::ostream&, const Date& );
	friend std::istream& operator>>( std::istream&, Date& );
	friend bool operator==( const Date&, const Date& );
	friend bool operator<( const Date&, const Date& );
	/* So, skip the above for now. */

	//.... more ? ...
private:
	int yr_;
	int mo_;
	int dy_;

	class CurrentDate {
	public:
		CurrentDate();
		int year_;
		int month_;
		int day_;
	};

	// Private functions...
	static int daysPM(int, int) ;
	bool isOK( int, int, int);
	void SetCurrentDate();

};  /* Class definition ends here */

// The put function prints "this" date on the standard output
// in the "DD/MM/YY" format
inline void Date::put(){
std::cout << std::setfill('0') << std::setw(2) << dy_ << "/" << std::setfill('0')<< std::setw(2) << mo_ << "/" << std::setfill('*') << std::setw(4) << yr_ << std::endl;
}


#endif /* MY_DATE_H_ */
