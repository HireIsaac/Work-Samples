/*
 * OneTime.h
 *
 *  Created on: Nov 29, 2018
 *      Author: Isaac Lohnes
 */

#ifndef ONETIME_H_
#define ONETIME_H_

#include "Appointment.h"
class OneTime: public Appointment {
public:
	OneTime();
	virtual ~OneTime();
	bool isDue(Date & dateToCompare);
};



#endif /* ONETIME_H_ */
