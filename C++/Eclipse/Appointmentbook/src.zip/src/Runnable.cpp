/*
 * Runnable.cpp
 *
 *  Created on: 29-Oct-2008
 *      Author: piotr
 */

#include "Runnable.h"

Runnable::Runnable() {
	// TODO Auto-generated constructor stub

}

Runnable::~Runnable() {
	// TODO Auto-generated destructor stub
}
