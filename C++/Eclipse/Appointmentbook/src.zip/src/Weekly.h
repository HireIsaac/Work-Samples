/*
 * Weekly.h
 *
 *  Created on: Nov 29, 2018
 *      Author: Isaac Lohnes
 */

#ifndef WEEKLY_H_
#define WEEKLY_H_

#include "Appointment.h"
class Weekly: public Appointment {
public:
	Weekly();
	virtual ~Weekly();
	bool isDue(Date & dateToCompare);
};



#endif /* WEEKLY_H_ */
