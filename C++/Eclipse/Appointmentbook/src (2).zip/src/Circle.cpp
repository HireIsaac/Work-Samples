/*
 * Circle.cpp
 *
 *  Created on: Dec 6, 2018
 *      Author: Isaac Lohnes
 */



#include "Shape.h"
#include "Circle.h"
#include <iostream>
using namespace std;
//
//Shape::Shape(){};
//Shape::~Shape(){};
//double Shape::area(){};
//bool Shape::isExternal(const Point&){};

