/*
 * Circle.h
 *
 *  Created on: Dec 6, 2018
 *      Author: Isaac Lohnes
 */

#ifndef CIRCLE_H_
#define CIRCLE_H_

#include "Shape.h"
#include "Point.h"


class Circle: public Shape {

public:
   Circle(int newx, int newy, int newradius);
   int getRadius();
   void setRadius(int newradius);
   void draw();

private:
   int radius;
};




#endif /* CIRCLE_H_ */
