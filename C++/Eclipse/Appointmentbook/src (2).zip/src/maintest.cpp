/*
 * maintest.cpp
 *
 *  Created on: Dec 6, 2018
 *      Author: Isaac Lohnes
 */






#include "Shape.h"
#include "Circle.h"

#include <iostream>
#include<string>
#include<fstream>
#include <unistd.h>

using namespace std;

int main() {

    string line;
    ifstream out("Book.txt");
    while(getline(out, line)) {
        cout << line << endl;
        usleep(1000);
    }
    out.close();
}
