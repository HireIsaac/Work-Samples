/*
 * Point.cpp
 *
 *  Created on: Dec 6, 2018
 *      Author: Isaac Lohnes
 */

#include "Point.h"




