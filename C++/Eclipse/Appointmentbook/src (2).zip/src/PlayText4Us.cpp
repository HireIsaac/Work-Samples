/*
 * PlayText4Us.cpp
 *
 *  Created on: Dec 6, 2018
 *      Author: Isaac Lohnes
 */


#include "Playable.h"
//
//setUp(book.txt){
//	//pass book to I/O
//}
//
//playIt(int){}
//
//play(){
//	//int here from playIt to run
//}



